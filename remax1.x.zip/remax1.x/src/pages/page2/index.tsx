import * as React from 'react';
import { View} from 'remax/wechat';

export default () => {
  return (
    <View>
      page2
    </View>
  );
};
